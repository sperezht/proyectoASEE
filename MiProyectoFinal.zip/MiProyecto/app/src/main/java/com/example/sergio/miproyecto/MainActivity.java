package com.example.sergio.miproyecto;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import org.json.JSONException;

import java.io.IOException;


public class MainActivity extends AppCompatActivity {

    Button preferencias,liga1,liga2,liga3,liga4,liga5;

    public static EquiposDAO dao;

    private boolean checkDataBase(String Database_path) {
        SQLiteDatabase checkDB = null;
        try {
            checkDB = SQLiteDatabase.openDatabase(Database_path, null, SQLiteDatabase.OPEN_READONLY);

            checkDB.close();
        } catch (SQLiteException e) {
        }
        if(checkDB==null){
            return false;
        }
        return true;
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
      /* if(!checkDataBase("/data/data/com.example.sergio.miproyecto/databases/Equiposdao.db")){
           try {
               dao=new EquiposDAO(this);
           } catch (IOException e) {
               e.printStackTrace();
           } catch (JSONException e) {
               e.printStackTrace();
           }
       }*/
        /*if(!checkDataBase("/data/data/com.example.sergio.miproyecto/databases/Equiposdao.db")){
            System.out.println("no esta");
        }

        else{
            System.out.println("si que esta");
        }*/
        try {
            dao=new EquiposDAO(this);
        } catch (IOException e) {
            e.printStackTrace();
        } catch (JSONException e) {
            e.printStackTrace();
        }

        preferencias=findViewById(R.id.MisEquipos);
        preferencias.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",-1);
                startActivity(intent);
            }
        });
        liga1=findViewById(R.id.Liga_1);
        liga1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",1);
                startActivity(intent);
            }
        });
        liga2=findViewById(R.id.Liga_2);
        liga2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",2);
                startActivity(intent);
            }
        });
        liga3=findViewById(R.id.Liga_3);
        liga3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",3);
                startActivity(intent);
            }
        });
        liga4=findViewById(R.id.Liga_4);
        liga4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",4);
                startActivity(intent);
            }
        });
        liga5=findViewById(R.id.Liga_5);
        liga5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(MainActivity.this,ClasificacionActivity.class);
                intent.putExtra("liga",5);
                startActivity(intent);
            }
        });


    }
}
