package com.example.sergio.miproyecto;

import android.content.ClipData;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

import static com.example.sergio.miproyecto.MainActivity.dao;

/**
 * Created by Sergio on 14/11/2017.
 */

public class EquiposAdapter extends RecyclerView.Adapter<EquiposAdapter.EquipoViewHolder> {

    private List<Equipos> equipos;
    public EquiposAdapter(List<Equipos> eq){
        equipos=eq;
    }
    @Override
    public EquipoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
       View v= LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item,parent,false);
       return new EquipoViewHolder(v);
    }

    @Override
    public void onBindViewHolder(EquipoViewHolder holder, int position) {
        Equipos e=equipos.get(position);
        holder.nombre.setText(e.getTeam());
        holder.ganados.setText("Ganados:"+e.getWon());
        holder.empatados.setText("Empatados:"+e.getDrawn());
        holder.perdidos.setText("Perdidos:"+e.getLost());
        holder.puntos.setText("Puntos:"+e.getPoints());
        holder.jugados.setText("Jugados:"+e.getPlayed());
        holder.favorables.setText("Goles favorables:"+e.getGoalsScored());
        holder.contra.setText("Goles en contra:"+e.getGoalsConceded());
        holder.dg.setText("Diferencia de goles:"+e.getGD());

       if(dao.esFavorito(e.getTeam())){
           holder.favorito.setText("eliminar de favoritos");
           holder.favorito.setChecked(true);
        }
        else{
           holder.favorito.setChecked(false);
           holder.favorito.setText("añadir a favoritos");

        }


    }

    @Override
    public int getItemCount() {
        return equipos.size();
    }

    public class EquipoViewHolder extends RecyclerView.ViewHolder {

       private CheckBox favorito;
       private TextView nombre;
       private TextView jugados;
        private TextView ganados;
        private TextView empatados;
        private TextView perdidos;
        private TextView puntos;
        private TextView favorables;
        private TextView contra;
        private TextView dg;

       public EquipoViewHolder(View ItemView){
           super(ItemView);
           nombre=(TextView) ItemView.findViewById(R.id.Nombrequipo);
           favorito=(CheckBox) ItemView.findViewById(R.id.esFav);
           favorito.setOnClickListener(new View.OnClickListener() {
               @Override
               /*
               * if(favorito.isChecked()&&dao.esFavorito(){
               * dejar a cierto y nada mas,
               * si no es favorito se añade.
               *
               * si no esta checkeado pero es fav entonces debemos mostrar como checkeado*/

               public void onClick(View v) {
                   if(favorito.isChecked()){
                       if(!dao.esFavorito(nombre.getText().toString())){
                           dao.ponerfav( nombre.getText().toString());
                       }
                       favorito.setText("eliminar de favoritos");

                   }
                   else{
                      if(dao.esFavorito(nombre.getText().toString())) {
                          dao.eliminarfav(nombre.getText().toString());
                      }

                       favorito.setText("añadir a favoritos");
                   }
               }
           });
           jugados=(TextView)ItemView.findViewById(R.id.djugados);
           ganados=(TextView)ItemView.findViewById(R.id.dganados);
           empatados=(TextView)ItemView.findViewById(R.id.dempatados);
           perdidos=(TextView)ItemView.findViewById(R.id.dperdidos);
           puntos=(TextView)ItemView.findViewById(R.id.dpuntos);
           favorables=(TextView)ItemView.findViewById(R.id.dfav);
           contra=(TextView)ItemView.findViewById(R.id.dcont);
           dg=(TextView)ItemView.findViewById(R.id.dg);
       }
    }
}
