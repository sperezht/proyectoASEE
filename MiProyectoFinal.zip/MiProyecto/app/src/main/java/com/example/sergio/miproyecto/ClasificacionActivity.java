package com.example.sergio.miproyecto;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


public class ClasificacionActivity extends AppCompatActivity {

    private List<Equipos> equipos;
    private RecyclerView listEquipos;
    private EquiposAdapter adaptador;
    Button volver;
    Button verfavoritos;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_clasificacion);
        if(this.getIntent().getExtras().getInt("liga")==-1){

            findViewById(R.id.verfavs).setVisibility(View.GONE);
        }
        else{
            findViewById(R.id.verfavs).setVisibility(View.VISIBLE);
            verfavoritos=findViewById(R.id.verfavs);
            verfavoritos.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent=new Intent(ClasificacionActivity.this,ClasificacionActivity.class);
                    intent.putExtra("liga",-1);
                    startActivity(intent);
                }
            });
        }

        listEquipos=(RecyclerView) findViewById(R.id.listaequipos);
        LinearLayoutManager lm=new LinearLayoutManager(this);
        lm.setOrientation(LinearLayoutManager.VERTICAL);
        listEquipos.setLayoutManager(lm);

        try {
            data();
           //Equipos.mostrarEquipos(equipos);
        } catch (IOException e) {
            System.out.println("algo ha ido mal");
        } catch (JSONException e) {
            e.printStackTrace();
        }
        inicializarAdaptador();

        volver=findViewById(R.id.VolverInicio);
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ClasificacionActivity.this,MainActivity.class);
                startActivity(intent);
            }
        });
    }
    public void data() throws IOException, JSONException {
       // equipos=new ArrayList<Equipos>();
        String archivo=new String();
        switch (this.getIntent().getExtras().getInt("liga")){
            case 1:
                archivo="SPAIN";
                break;
            case 2:
                archivo="FRANCE";
                break;
            case 3:
                archivo="ENGLAND";
                break;
            case 4:
                archivo="ITALY";
                break;
            case 5:
                archivo="GERMANY";
                break;

        }
        //Equipos.cargarInformacion(archivo,equipos,this);
        if(this.getIntent().getExtras().getInt("liga")!=-1){
            equipos=MainActivity.dao.ConsultarLiga(archivo);
        }
        else{
            equipos=MainActivity.dao.consultarFavoritos();
        }
       // Equipos.mostrarEquipos(equipos);


    }
    public void inicializarAdaptador(){
       //Equipos.mostrarEquipos(equipos);

        adaptador=new EquiposAdapter(equipos);
        listEquipos.setAdapter(adaptador);
    }
}
