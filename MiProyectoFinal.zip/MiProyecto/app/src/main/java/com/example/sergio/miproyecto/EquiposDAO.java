package com.example.sergio.miproyecto;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Sergio on 15/11/2017.
 */

public class EquiposDAO extends SQLiteOpenHelper {
    String createTable="create table Equipos(Team String primary key,Liga String,Played Integer,Won Integer," +
            "Drawn Integer,Lost Integer,Scored Integer,Conceded Integer,GD Integer,Points Integer,Favorito String default 'NO')";


    public EquiposDAO(Context context) throws IOException, JSONException {
            super(context, "Equiposdao.db", null, 1);
            if(DAOVacio()){
                RellenarDAO(context);
            }



    }
    public boolean DAOVacio(){
        Cursor c;
        boolean salida=false;
        SQLiteDatabase db = getReadableDatabase();
        c=db.rawQuery("SELECT count(*)" +
                " FROM EQUIPOS",null);
        if(c.moveToFirst()){
            if(c.getInt(0)==0){
                salida=true;
            }
        }
        return salida;
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DELETE FROM EQUIPOS");
        //db.execSQL(createTable);
    }
    public void onUpgrade(){
        SQLiteDatabase db=getWritableDatabase();
        onUpgrade(db,0,0);
    }
    public void Insertar(Equipos equipo,String Liga){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("INSERT INTO EQUIPOS(TEAM,LIGA,PLAYED,WON,DRAWN,LOST,SCORED,CONCEDED,GD,POINTS)" +
                "VALUES('"+equipo.getTeam()+"','"+Liga+"',"+equipo.getPlayed()+","+equipo.getWon()+","+
                equipo.getDrawn()+","+equipo.getLost()+","+equipo.getGoalsScored()+","+equipo.getGoalsConceded()+","+
                equipo.getGD()+","+equipo.getPoints()+")");
    }
    public void eliminar(Equipos equipo){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DELETE FROM EQUIPOS WHERE TEAM='"+equipo.getTeam()+"'");
    }
    public void eliminarDAO(){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("DROP TABLE EQUIPOS IF exists");
    }
    public void RellenarDAO(Context context) throws IOException, JSONException {
        SQLiteDatabase db = getWritableDatabase();
        List<Equipos> listae=new ArrayList<Equipos>();
        Equipos.cargarInformacion("clasificacionespana.json",listae,context);
        for(int i=0;i<listae.size();i++){
            //eliminar(listae.get(i));
            Insertar(listae.get(i),"SPAIN");
        }
        listae=new ArrayList<Equipos>();
        Equipos.cargarInformacion("clasificacionalemania.json",listae,context);
        for(int i=0;i<listae.size();i++){
            //eliminar(listae.get(i));
            Insertar(listae.get(i),"GERMANY");
        }
        listae=new ArrayList<Equipos>();
        Equipos.cargarInformacion("clasificacionfrancia.json",listae,context);
        for(int i=0;i<listae.size();i++){
           // eliminar(listae.get(i));
            Insertar(listae.get(i),"FRANCE");
        }
        listae=new ArrayList<Equipos>();
        Equipos.cargarInformacion("clasificacionitalia.json",listae,context);
        for(int i=0;i<listae.size();i++){
           // eliminar(listae.get(i));
            Insertar(listae.get(i),"ITALY");
        }
        listae=new ArrayList<Equipos>();

        Equipos.cargarInformacion("clasificacioninglaterra.json",listae,context);
        for(int i=0;i<listae.size();i++){
            //eliminar(listae.get(i));
            Insertar(listae.get(i),"ENGLAND");
        }
    }
    public void ponerfav(String cual){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("update Equipos set Favorito='SI' where Team='"+cual+"'");
    }
    public void eliminarfav(String cual){
        SQLiteDatabase db = getWritableDatabase();
        db.execSQL("update Equipos set Favorito='NO' where Team='"+cual+"'");
    }
    /*public Equipos devolverEquipo(SQLiteDatabase db,String eq){
        Cursor c;
        Equipos e=null;
        c=db.rawQuery("SELECT TEAM,PLAYED,WON,DRAWN,LOST,SCORED,CONCEDED,GD,POINTS,FAVORITO" +
                " FROM EQUIPOS WHERE TEAM='"+eq+"'",null);
        if(c.moveToFirst()){
            e=new Equipos(c.getString(0),c.getInt(1),c.getInt(2),c.getInt(3),
                    c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7),
                    c.getInt(8));
        }
        return e;
    }*/
    public boolean esFavorito(String e){
        Cursor c;
        boolean salida=false;
        SQLiteDatabase db = getReadableDatabase();
        c=db.rawQuery("SELECT FAVORITO" +
                " FROM EQUIPOS WHERE TEAM='"+e+"'",null);
        if(c.moveToFirst()){
            if(c.getString(0).equals("SI")){
                salida=true;
            }
        }
        return salida;
    }
    public List<Equipos> consultarFavoritos(){
        List<Equipos> listae=new ArrayList<Equipos>();
        Cursor c;
        Equipos e;
        SQLiteDatabase db = getReadableDatabase();
        c=db.rawQuery("SELECT TEAM,PLAYED,WON,DRAWN,LOST,SCORED,CONCEDED,GD,POINTS,FAVORITO" +
                " FROM EQUIPOS WHERE FAVORITO='SI'",null);
        if(c.moveToFirst()){
            do{
                e=new Equipos(c.getString(0),c.getInt(1),c.getInt(2),c.getInt(3),
                        c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7),
                        c.getInt(8));
                listae.add(e);
            }while(c.moveToNext());
        }
        return listae;

    }
    public List<Equipos> ConsultarLiga(String filtro){
        List<Equipos> listae=new ArrayList<Equipos>();
        Cursor c;
        Equipos e;
        SQLiteDatabase db = getReadableDatabase();
        c=db.rawQuery("SELECT TEAM,PLAYED,WON,DRAWN,LOST,SCORED,CONCEDED,GD,POINTS,FAVORITO" +
                " FROM EQUIPOS WHERE Liga='"+filtro+"'",null);
        if(c.moveToFirst()){
            do{
                //System.out.println("mostrando equipo consultado "+c.getString(0));
                e=new Equipos(c.getString(0),c.getInt(1),c.getInt(2),c.getInt(3),
                        c.getInt(4),c.getInt(5),c.getInt(6),c.getInt(7),
                        c.getInt(8));
                listae.add(e);
            }while(c.moveToNext());
           // System.out.println("mostrando en a");
            //Equipos.mostrarEquipos(listae);
        }
        return listae;

    }
}
