

        package com.example.sergio.miproyecto;

        import android.content.Context;

        import java.io.BufferedReader;
        import java.io.IOException;
        import java.io.InputStream;
        import java.io.InputStreamReader;
        import java.util.ArrayList;
        import java.util.HashMap;
        import java.util.List;
        import java.util.Map;
        import com.fasterxml.jackson.annotation.JsonAnyGetter;
        import com.fasterxml.jackson.annotation.JsonAnySetter;
        import com.fasterxml.jackson.annotation.JsonIgnore;
        import com.fasterxml.jackson.annotation.JsonInclude;
        import com.fasterxml.jackson.annotation.JsonProperty;
        import com.fasterxml.jackson.annotation.JsonPropertyOrder;

        import org.json.JSONArray;
        import org.json.JSONException;
        import org.json.JSONObject;

        @JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "Team",
        "Played",
        "Won",
        "Drawn",
        "Lost",
        "Goals scored",
        "Goals conceded",
        "GD",
        "Points"
})
public class Equipos {

    @JsonProperty("Team")
    private String team;
    @JsonProperty("Played")
    private Integer played;
    @JsonProperty("Won")
    private Integer won;
    @JsonProperty("Drawn")
    private Integer drawn;
    @JsonProperty("Lost")
    private Integer lost;
    @JsonProperty("Goals scored")
    private Integer goalsScored;
    @JsonProperty("Goals conceded")
    private Integer goalsConceded;
    @JsonProperty("GD")
    private Integer gD;
    @JsonProperty("Points")
    private Integer points;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    public Equipos(JSONObject object) throws JSONException {
        setTeam(object.getString("Team"));
        setPlayed(object.getInt("Played"));
        setWon(object.getInt("Won"));
        setDrawn(object.getInt("Drawn"));
        setLost(object.getInt("Lost"));
        setGoalsScored(object.getInt("Goals scored"));
        setGoalsConceded(object.getInt("Goals conceded"));
        setGD(object.getInt("GD"));
        setPoints(object.getInt("Points"));
    }
    public Equipos(String name,int played,int won,int drawn,int lost,int goalsScored,
                   int goalsConceded,int gd,int points){
        setTeam(name);
        setPlayed(played);
        setWon(won);
        setDrawn(drawn);
        setLost(lost);
        setGoalsScored(goalsScored);
        setGoalsConceded(goalsConceded);
        setPoints(points);
        setGD(gd);
    }

    @JsonProperty("Team")
    public String getTeam() {
        return team;
    }

    @JsonProperty("Team")
    public void setTeam(String team) {
        this.team = team;
    }

    @JsonProperty("Played")
    public Integer getPlayed() {
        return played;
    }

    @JsonProperty("Played")
    public void setPlayed(Integer played) {
        this.played = played;
    }

    @JsonProperty("Won")
    public Integer getWon() {
        return won;
    }

    @JsonProperty("Won")
    public void setWon(Integer won) {
        this.won = won;
    }

    @JsonProperty("Drawn")
    public Integer getDrawn() {
        return drawn;
    }

    @JsonProperty("Drawn")
    public void setDrawn(Integer drawn) {
        this.drawn = drawn;
    }

    @JsonProperty("Lost")
    public Integer getLost() {
        return lost;
    }

    @JsonProperty("Lost")
    public void setLost(Integer lost) {
        this.lost = lost;
    }

    @JsonProperty("Goals scored")
    public Integer getGoalsScored() {
        return goalsScored;
    }

    @JsonProperty("Goals scored")
    public void setGoalsScored(Integer goalsScored) {
        this.goalsScored = goalsScored;
    }

    @JsonProperty("Goals conceded")
    public Integer getGoalsConceded() {
        return goalsConceded;
    }

    @JsonProperty("Goals conceded")
    public void setGoalsConceded(Integer goalsConceded) {
        this.goalsConceded = goalsConceded;
    }

    @JsonProperty("GD")
    public Integer getGD() {
        return gD;
    }

    @JsonProperty("GD")
    public void setGD(Integer gD) {
        this.gD = gD;
    }

    @JsonProperty("Points")
    public Integer getPoints() {
        return points;
    }

    @JsonProperty("Points")
    public void setPoints(Integer points) {
        this.points = points;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }
    public static void mostrarEquipos(List<Equipos>equipos){
        System.out.println("mostrando los equipos procesados");
        for(int i=0;i<equipos.size();i++){
            System.out.println(equipos.get(i).getTeam());
        }
    }
    public static void cargarInformacion(String archivo,List<Equipos> lista,Context context) throws JSONException, IOException {
        InputStream fraw = null;
        switch(archivo){
            case "clasificacionespana.json":
                fraw=context.getResources().openRawResource(R.raw.clasificacionespana);
                break;
            case "clasificacionalemania.json":
                fraw=context.getResources().openRawResource(R.raw.clasificacionalemania);
                break;
            case "clasificacionfrancia.json":
                fraw=context.getResources().openRawResource(R.raw.clasificacionfrancia);
                break;
            case "clasificacioninglaterra.json":
                fraw=context.getResources().openRawResource(R.raw.clasificacioninglaterra);
                break;
            case "clasificacionitalia.json":
                fraw=context.getResources().openRawResource(R.raw.clasificacionitalia);
                break;
                default:
                    fraw=context.getResources().openRawResource(R.raw.clasificacionitalia);
                    break;
        }
        BufferedReader br = new BufferedReader(new InputStreamReader(fraw));
        String linea;
        String datoLeido = new String();
        while((linea=br.readLine())!=null) {
            datoLeido = datoLeido + linea;
        }
        boolean esObjeto=false;
        linea=new String();
        for(int i=0;i<datoLeido.length();i++){
            if(datoLeido.charAt(i)=='{'){
                esObjeto=true;
            }
            if(datoLeido.charAt(i)=='}'){
                linea=linea+datoLeido.charAt(i);
                //System.out.println(linea);
                JSONObject object = new JSONObject(linea);
                lista.add(new Equipos(object));
                esObjeto=false;
                linea=new String();
            }
            if(esObjeto){
                linea=linea+datoLeido.charAt(i);
            }
        }
        //mostrarEquipos(lista);

    }

}